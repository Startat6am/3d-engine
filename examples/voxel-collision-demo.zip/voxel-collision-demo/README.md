# Voxel Collision Demo

A small 4-chunk voxel world for testing Player static terrain colliders.

- 4 adjacent 16×16×16 chunks
- Voxel size: 1 world unit
- Ground slab with grass/dirt/stone layers
- Raised platforms and stepped obstacles
- Stored as a native Choreon directory project (worlds/main.world + content-addressed voxel chunk blobs)

## Open in Player

1. Start the Player app.
2. Choose **Open project** and select this folder (or unzip the companion archive first).
3. Wait for the project to load. The status should report **4 static voxel colliders**.

The current Player has terrain colliders wired into Rapier but does not yet include a controllable character. This fixture validates voxel project loading and static collider creation, not character movement.
